<style>
	input[type="date"] {
		outline: none !important;
		border: 0px solid !important;
	}
</style>
<div class="row">
	<div class="col-md-12">
		<div class="card mb-3">
			<div class="card-header with-elements"> <span class="card-header-title mr-2"><strong>Proof of Transfer</strong></span>
				<div class="card-body">
					<table class="table table-stripped table-hover" id="xin_table">
						<tbody>
							<tr>
								<td>Amount</td>
								<td>000.000.000</td>
							</tr>
							<tr>
								<td>Nilai Terbilang</td>
								<td>Kosong</td>
							</tr>
							<tr>
								<td>Reference</td>
								<td>none</td>
							</tr>
							<tr>
								<td>Note</td>
								<td>Lorem Ipsum</td>
							</tr>

						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>